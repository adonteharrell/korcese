#!/bin/bash


basename -a /storage/webserver/*.mp4 | less

