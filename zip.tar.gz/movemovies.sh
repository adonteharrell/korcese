#!/bin/bash
date=$(date +%F---%r)

sudo echo "==============================================================================================" >> /storage/webserver/movies/movements.txt
sudo echo "MOVEMENT STARTED AT $date" >> /storage/webserver/movies/movements.txt
sudo echo "==============================================================================================" >> /storage/webserver/movies/movements.txt

cd "/windows/Videos" 

for i in *.mp4; do 
    grep -x "$i" /storage/webserver/movies/movielist.txt
    if [ $? -eq 0 ]; then
        echo "Movie already exists"
    else
        echo "$i" >> /storage/webserver/movies/movielist.txt
        sudo find /windows/Videos/*/ -type f -name "$i" -exec cp -u -v {} /storage/webserver/movies \;
    fi
done

for i in *.mkv; do
    grep -x "$i" /storage/webserver/movies/movielist.txt
    if [ $? -eq 0 ]; then
        echo "Movie already exists"
    else
        sudo find /windows/Videos/*/ -type f -name "$i" -exec cp -u -v {} /storage/webserver/movies \;
    fi
done 
cd "/storage/webserver/movies"
sudo sh /storage/webserver/movies/convert.sh
sudo rm -f /storage/webserver/movies/*.mkv
sudo sh /home/remuser/currenttime.sh
