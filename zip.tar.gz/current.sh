#!/bin/bash

time=$(date +%r)

echo "ver. 1.0.0                         $time"

